
import os
import sys

from PyQt5 import QtGui, QtWidgets
from PyQt5.QtCore import *

NO_PICOS_MESSAGE = \
''' The Oscilloscope application was unable to find any AMC-Pico-8 device on this system.

Please check if:
1. the AMC-Pico-8 board is plugged-in and powered on
2. the MCH provides a PCIe link between AMC-Pico-8 and CPU board
3. the AMC-Pico-8 Linux driver is loaded
'''


def getScriptPath():
    return os.path.dirname(os.path.realpath(sys.argv[0]))


class PicoSelector(QtGui.QDialog):
    def __init__(self, parent=None):
        super(PicoSelector, self).__init__(parent)
        self.setWindowTitle('CAENels AMC-Pico-8 Oscilloscope')
        self.picoList = QtGui.QListWidget()

        self.okButton = QtGui.QPushButton('OK')
        self.okButton.setDefault(True)
        cancelButton = QtGui.QPushButton('Cancel')

        caenelsPixmap = QtGui.QPixmap(getScriptPath() + '/CAENels.png')
        caenelsLabel = QtGui.QLabel()
        caenelsLabel.setPixmap(caenelsPixmap)

        self.okButton.released.connect(self.accept)
        cancelButton.released.connect(self.reject)

        self.populate_picolist()

        layout = QtGui.QFormLayout()
        layout.addRow(caenelsLabel)
        layout.addRow(QtGui.QLabel(''))
        layout.addRow(QtGui.QLabel('Select AMC-Pico-8 board:'))
        layout.addRow(self.picoList)
        layout.addRow(cancelButton, self.okButton)
        self.setLayout(layout)

    def get_pico_path(self):
        return str(self.picoList.currentItem().text())

    def populate_picolist(self):
        picos = filter(lambda name: name.find('amc_pico') == 0, os.listdir('/dev'))

        # OK button is disabled if no pico is shown
        self.okButton.setEnabled(False)

        for pico in picos:
            item = QtWidgets.QListWidgetItem('/dev/' + pico)
            self.picoList.addItem(item)

            self.picoList.setCurrentItem(item)
            self.okButton.setEnabled(True)

        if self.picoList.count() == 0:
            QtGui.QMessageBox.warning(self, 'No AMC-Pico-8 board found',
                NO_PICOS_MESSAGE)
