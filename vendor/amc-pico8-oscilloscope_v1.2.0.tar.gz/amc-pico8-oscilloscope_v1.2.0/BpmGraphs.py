
import sys
import os

from PyQt5 import QtGui, QtWidgets, uic
import numpy as np


def getScriptPath():
    return os.path.dirname(os.path.realpath(sys.argv[0]))


class BpmGraphs(QtGui.QDialog):

    colors = ["#FFFF00", "#FF1493", "#00BFFF", "#00FF7F",
              "#FF8C00", "#BA55D3", "#87CEEB", "#BAFF00"]

    def __init__(self, parent=None):
        super(BpmGraphs, self).__init__(parent)

        self.ui = uic.loadUi(getScriptPath() + "/bpm_graphs.ui", self)

        # example
        self.add_list_widget('Hor pos',
                             '(data[0]-data[2])/(data[0]+data[2])*1e-9')
        self.add_list_widget('Vert pos',
                             '(data[1]-data[3])/(data[1]+data[3])*1e-9')
        self.add_list_widget('I0',
                             '(data[0]+data[1]+data[2]+data[3])')

        # set graphs
        self.ui.graph.showGrid(x=True, y=True)

        self.plot = []

        for i in range(8):
            self.plot.append(self.ui.graph.plot(pen=self.colors[i]))

        # signals/slots
        self.plotList.itemClicked.connect(self.on_item_selected)
        self.ui.addPlotButton.released.connect(self.on_addPlot_released)
        self.ui.removePlotButton.released.connect(self.on_removePlot_released)
        self.ui.updatePlot.released.connect(self.on_updateConfig_released)

    def on_item_selected(self, item):
        self.ui.textPlotName.setText(item.text())
        self.ui.textPlotEq.document().setPlainText(item.data(1001))

    def on_addPlot_released(self):
        new_plot_name = 'ch{0}'.format(self.plotList.count())
        new_plot_eq = 'data[{0}]'.format(self.plotList.count())
        self.add_list_widget(new_plot_name, new_plot_eq)

    def on_removePlot_released(self):
        self.plotList.takeItem(self.plotList.currentRow())

    def on_updateConfig_released(self):
        self.plotList.currentItem().setText(self.textPlotName.text())
        self.plotList.currentItem().setData(1001, self.ui.textPlotEq.document().toPlainText())

    def add_list_widget(self, name, f):
        if self.plotList.count() < 8:
            pixmap = QtGui.QPixmap(100, 100)
            pixmap.fill(QtGui.QColor(self.colors[self.plotList.count()]))
            icon = QtGui.QIcon(pixmap)
            widget = QtWidgets.QListWidgetItem(icon, name)
            widget.setData(1001, f)
            widget.setData(1002, self.plotList.count())
            self.plotList.addItem(widget)

    def draw_plot(self, data):
        ''' Args:
                data: numpy list of values

        '''

        ploted = []

        for i in range(self.plotList.count()):
            plot_idx = self.plotList.item(i).data(1002)
            eval('self.plot[{i}].setData({f})'.format(
                i=plot_idx, f=self.plotList.item(i).data(1001)))
            ploted.append(plot_idx)

        # clear old
        for i in range(8):
            if i not in ploted:
                self.plot[i].clear()
