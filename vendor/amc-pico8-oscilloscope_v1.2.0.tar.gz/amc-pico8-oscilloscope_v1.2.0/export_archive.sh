#! /bin/bash


# get version
VERSION=$(cat oscilloscope.py | grep __version__ | awk -F'= ' '{print $2}' | sed -e "s/'//g")
echo "Exporting version: $VERSION"

git archive --format=tgz HEAD --prefix=amc-pico8-oscilloscope_v$VERSION/ > ../amc-pico8-oscilloscope_v$VERSION.tar.gz

echo "Created ../amc-pico8-oscilloscope_v$VERSION.tar.gz"

echo "Created file contains":
tar tvf ../amc-pico8-oscilloscope_v$VERSION.tar.gz
