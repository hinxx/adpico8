
Dependencies
=============

PyQt5
-----

    sudo apt-get install python3-pyqt5 python3-pyqt5.qtsvg

PyQtGraph
---------

    git clone -b pyqt5 https://github.com/pyqtgraph/pyqtgraph.git
    cd pyqtgraph
    sudo python3 setup.py install
