#! /bin/bash

# Creates .Desktop file pointing to oscilloscope.py

SHORTCUT_PATH=$HOME/Desktop/amc_pico_8.Desktop
echo "Creating shortcut file at: $SHORTCUT_PATH"


APP_PATH=$(pwd)/oscilloscope.py
echo "Application path: $APP_PATH"

file $APP_PATH > /dev/null
if [[ $? -ne 0 ]]; then
	echo "Error: $APP_PATH does not exits"
	echo "Exiting"
	exit 1
fi


ICON_PATH=$(pwd)/oscilloscope_icon.png
echo "Icon path: $APP_PATH"

file $ICON_PATH > /dev/null
if [[ $? -ne 0 ]]; then
	echo "Error: $APP_PATH does not exits"
	echo "Exiting"
	exit 1
fi


echo "[Desktop Entry]
Name=AMC-Pico8 Oscilloscope
Exec=$APP_PATH
Icon=$ICON_PATH
Terminal=false
Type=Application" > $SHORTCUT_PATH

chmod +x $SHORTCUT_PATH

echo "Shortcut file succesfully created"
